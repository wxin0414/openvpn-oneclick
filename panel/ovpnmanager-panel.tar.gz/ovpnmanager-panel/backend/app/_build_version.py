# 由 pack.sh 生成，不要手改。
VERSION = "2.0.2"
