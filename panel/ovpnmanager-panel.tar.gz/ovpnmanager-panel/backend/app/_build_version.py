# 由 pack.sh 生成，不要手改。
VERSION = "1.9.9"
